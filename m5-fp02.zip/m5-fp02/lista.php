<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LISTA - FP02</title>
</head>
<body>
    <h3> Exercicio 1 </h3>
    <?php
        $item1 = $_POST["item1"];
        $item2 = $_POST["item2"];
        $item3 = $_POST["item3"];
        $item4 = $_POST["item4"];
        $item5 = $_POST["item5"];
        $lista = array($item1, $item2, $item3, $item4, $item5);

    echo "<ul>";
        foreach ($lista as $item) {
            echo "<li>$item</li>";
        }
    echo "</ul>";
    ?>

<!-- --------------------------------------------------------------------------------- -->

    <h3> Exercicio 2 </h3>
    <?php
    $turma = [
        "Ana"  => 16,
        "João" => 17,
        "Mara" => 18,
        "Paulo" => 17,
        "Guilherme" => 16   
    ];
    
    echo "<table border='2' width= '160'>";
    foreach ($turma as $nome => $idade) {
        echo "<tr>";
        echo "<td>$nome</td>";
        echo "<td>$idade</td>";
        echo "</tr>";
    }
    echo "</table>";
    ?>

<!-- --------------------------------------------------------------------------------- -->

    <h3> Exercicio 3 </h3>
    <?php
    $notas = [
        $_POST["nota1"],
        $_POST["nota2"],
        $_POST["nota3"],
        $_POST["nota4"],
        $_POST["nota5"]
    ];
    $soma = array_sum($notas);
    $quantidade = count($notas);
    $media = $soma / $quantidade;
    
    if ($media < 10) {
        $resultado = "Reprovado";
    } elseif ($media <= 13) {
        $resultado = "Satisfaz";
    } elseif ($media <= 17) {
        $resultado = "Bom";
    } else {
        $resultado = "Excelente";
    }
    
    echo "<strong>Média: $media</strong>";
    echo "<br>";
    echo "<strong>Resultado:  $resultado</strong>";
    ?>
</body>
</html>